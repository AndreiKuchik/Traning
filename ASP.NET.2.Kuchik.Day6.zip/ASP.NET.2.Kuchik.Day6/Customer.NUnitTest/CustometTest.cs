﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using ASP.NET._2.Kuchik.Day6;

namespace Customer.NUnitTest
{
    public class CustometTest
    {
        public IEnumerable<TestCaseData> TestDatas
        {
            get
            {
                yield return new TestCaseData("NcR").Returns("Customer record: Andrei, +3, 345");
                yield return new TestCaseData("NC").Returns("Customer record: Andrei, +3");
                yield return new TestCaseData("N").Returns("Customer record: Andrei");
                yield return new TestCaseData("cR").Returns("Customer record: +3, 345");
                yield return new TestCaseData("r").Returns("Customer record: 345");
                yield return new TestCaseData("C").Returns("Customer record: +3");
                yield return new TestCaseData("NBVC").Throws(typeof(FormatException));
            }
        }

        [Test, TestCaseSource("TestDatas")]
        public string ToString_WithAllVariant(string format)
        {
            ASP.NET._2.Kuchik.Day6.Customer customer = new ASP.NET._2.Kuchik.Day6.Customer("Andrei", "+3", 345);
           
            string actResultString = customer.ToString(format);

            return actResultString;
        }


        public IEnumerable<TestCaseData> TestData
        {

            get
            {
                yield return new TestCaseData("WL").Returns("Name: Andrei\n ContactPhone: +3\n Revenue: 345\n");
                yield return new TestCaseData("Ws").Returns("Name: Andrei ContactPhone: +3 Revenue: 345");
                yield return new TestCaseData("A").Returns("Customer record: Andrei, +3, 345");
                yield return new TestCaseData(null).Throws(typeof(ArgumentException));
            }
        }

        [Test, TestCaseSource("TestData")]
        public string FormatWithAllVariant(string format)
        {
           
            CustomFormatter test = new CustomFormatter();
            ASP.NET._2.Kuchik.Day6.Customer customer = new ASP.NET._2.Kuchik.Day6.Customer("Andrei", "+3", 345);
           string  res = test.Format(format, customer, CultureInfo.CurrentCulture);

            return res;
        }


    }
}
