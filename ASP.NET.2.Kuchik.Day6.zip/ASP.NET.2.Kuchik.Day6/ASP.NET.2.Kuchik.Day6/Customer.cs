﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day6
{
    public class Customer: IFormattable
    {
        #region Private filds
        private delegate string DisplayForms();

        private Dictionary<string, DisplayForms> typeOfDisplay;
#endregion

        #region Public filds
        public string Name { get; private set; }
        public string ContactPhone { get; private set; }
        public decimal Revenue { get; private set; }

#endregion

#region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public Customer()
        {

            typeOfDisplay = new Dictionary<string, DisplayForms>()
            {
                {"N", new DisplayForms(OutputN)},
                {"NC", new DisplayForms(OutputNC)},
                {"NR", new DisplayForms(OutputNR)},
                {"NCR", new DisplayForms(OutputAll)},
                {"C", new DisplayForms(OutputC)},
                {"CR", new DisplayForms(OutputCR)},
                {"R", new DisplayForms(OutputR)}
            };
            Name = "default";
            ContactPhone = "default";
            Revenue = 0;
        }

        /// <summary>
        /// Constructor with parametrs
        /// </summary>
        /// <param name="name"></param>
        /// <param name="contactphone"></param>
        /// <param name="revenue"></param>
        public Customer(string name, string contactphone, decimal revenue):this()
        {
            if (name == null)
                throw new ArgumentException();
            else
            Name = name;
            if (contactphone == null)
                throw new ArgumentException();
            else
                ContactPhone = contactphone;
            
                Revenue = revenue;
        }

#endregion

#region Public methods

        /// <summary>
        /// generates a string representation of the form
        /// </summary>
        /// <returns>string representation</returns>
        public string ToString()
        {
            return ToString("N", CultureInfo.CurrentCulture);
        }

       /// <summary>
        /// generates a string representation of the form
       /// </summary>
       /// <param name="format"></param>
        /// <returns>string representation</returns>
        public string ToString(string format)
        {
            if (format ==null )
                throw new ArgumentException();
            else
            return ToString(format, CultureInfo.CurrentCulture);
        }

        /// <summary>
        /// generates a string representation of the form
        /// </summary>
        /// <param name="formatProvider"></param>
        /// <returns>string representation</returns>
        public string ToString(IFormatProvider formatProvider)
        {
            return ToString("N", formatProvider);
        }

        /// <summary>
        /// generates a string representation of the form
        /// </summary>
        /// <param name="format"></param>
        /// <param name="formatProvider"></param>
        /// <returns>string representation</returns>
        public string ToString(string format, IFormatProvider formatProvider)
        {

            if (format == null)
                throw new ArgumentException("parametr 'format' is null");
            
            format = format.ToUpper();
            if (typeOfDisplay.ContainsKey(format))
            {
                return typeOfDisplay[format]();
            }
            else
            {
               throw new FormatException(string.Format("{0} does not exist.", format));
            }
        }

#endregion

        /// <summary>
        ///  Methods generates a string representation of various types
        /// </summary>
        /// <returns>string representation different forms</returns>
#region Private methods
        private string OutputAll()
        {
             return string.Format("Customer record: {0}, {1}, {2}",Name, ContactPhone, Revenue);
        }
        private string OutputNC()
        {
             return string.Format("Customer record: {0}, {1}",Name,ContactPhone);
        }
        private string OutputN()
        {
             return string.Format("Customer record: {0}",Name);
        }
        private string OutputCR()
        {
             return string.Format("Customer record: {0}, {1}", ContactPhone, Revenue);
        }
        private string OutputC()
        {
             return string.Format("Customer record: {0}",ContactPhone);
        }
        private string OutputR()
        {
             return string.Format("Customer record: {0}",Revenue);
        }
        private string OutputNR()
        {
             return string.Format("Customer record: {0}, {1}",Name,Revenue);
        }  
         
#endregion   
                
    }
}
