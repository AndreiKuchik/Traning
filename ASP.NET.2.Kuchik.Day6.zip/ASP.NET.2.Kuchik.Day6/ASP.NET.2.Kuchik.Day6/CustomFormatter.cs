﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day6
{
    public class CustomFormatter: IFormatProvider, ICustomFormatter
    {
        # region Private filds
        private delegate string OutPutFormat(Customer customer);
        private Dictionary<string, OutPutFormat> typeOfDisplay;
        private IFormatProvider parent;
#endregion

        # region Constructors

        /// <summary>
        /// Constructor
        /// </summary>
        public CustomFormatter()
            : this(CultureInfo.CurrentCulture)
        {

        }
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="_provider"></param>
        public CustomFormatter(IFormatProvider _provider)
        {
            parent = _provider;
            typeOfDisplay = new Dictionary<string, OutPutFormat>()
            {
                {"A", new OutPutFormat(OutPutAlways)},
                {"WS", new OutPutFormat(OutPutWithString)},
                {"WL", new OutPutFormat(OutPutWithLines)},
              
            };

        }

        #endregion


        # region Public methods

        /// <summary>
        /// Returns an object that provides formatting services for the specified type
        /// </summary>
        /// <param name="formatType"></param>
        /// <returns>object that provides formatting services</returns>
        public object GetFormat(Type formatType)
        {
            if (formatType == typeof (ICustomFormatter))
                return this;
            return null;
        }

        /// <summary>
        /// Converts the value of a specified object to an equivalent string representation using specified format 
        /// </summary>
        /// <param name="format"></param>
        /// <param name="arg"></param>
        /// <param name="formatProvider"></param>
        /// <returns>string representation</returns>
        public string Format(string format, object arg, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                throw new ArgumentException("paramtr 'format' is null!");
            }
            Customer customer = arg as Customer;
            if (customer == null)
            {
                throw new ArgumentException("paramter 'arg' is wrong!");
            }

            format = format.ToUpper();
            if (typeOfDisplay.ContainsKey(format))
            {
                return typeOfDisplay[format](customer);
            }
            
            return typeOfDisplay["A"](customer);

        }

#endregion


        /// <summary>
        ///  The method creates a string representation, depending on the type of presentation
        /// </summary>
        /// <returns>string representation different forms</returns>
        #region Private methods
        private string OutPutAlways(Customer customer)
        {
            return string.Format("Customer record: {0}, {1}, {2}", customer.Name, customer.ContactPhone, customer.Revenue);
        }

        private string OutPutWithString(Customer customer)
        {
            return String.Format("Name: {0} ContactPhone: {1} Revenue: {2}",
                customer.Name, customer.ContactPhone, customer.Revenue);
        }

        private string OutPutWithLines(Customer customer)
        {
            return String.Format("Name: {0}\n ContactPhone: {1}\n Revenue: {2}\n",
                customer.Name, customer.ContactPhone, customer.Revenue);
        }
#endregion

     }
}
