﻿using System;
using System.Globalization;
using ASP.NET._2.Kuchik.Day6;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CustomerTest
{
    [TestClass]
    public class CustomFormatterTest
    {
        
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestFormatWithNullFormat()
        {
            //Arrange

            string formt = null;
            Customer customer = new Customer();
            CustomFormatter test = new CustomFormatter();
            //Act
            test.Format(formt,customer, CultureInfo.CurrentCulture);

            //Assert
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestFormatWithNullObj()
        {
            //Arrange

            string formt = "A";
            Customer customer = null;
            CustomFormatter test = new CustomFormatter();
            //Act
            test.Format(formt, customer, CultureInfo.CurrentCulture);

            //Assert
        }

        [TestMethod]
        public void TestFormatDataWithFormatA()
        {

            string formt = "A";
            string res;
            Customer customer = new Customer("Andrei", "+3", 345);
            CustomFormatter test = new CustomFormatter();
            
            //Act
            res = test.Format(formt, customer, CultureInfo.CurrentCulture);

            //Assert
            Assert.AreEqual("Customer record: Andrei, +3, 345", res);
        }

        [TestMethod]
        public void TestFormatDataWithFormatWS()
        {

            string formt = "WS";
            string res;
            Customer customer = new Customer("Andrei", "+3", 345);
            CustomFormatter test = new CustomFormatter();

            //Act
            res = test.Format(formt, customer, CultureInfo.CurrentCulture);

            //Assert
            Assert.AreEqual("Name: Andrei ContactPhone: +3 Revenue: 345", res);
        }

        [TestMethod]
        public void TestFormatDataWithFormatWL()
        {

            string formt = "WL";
            string res;
            Customer customer = new Customer("Andrei", "+3", 345);
            CustomFormatter test = new CustomFormatter();

            //Act
            res = test.Format(formt, customer, CultureInfo.CurrentCulture);

            //Assert
            Assert.AreEqual("Name: Andrei\n ContactPhone: +3\n Revenue: 345\n", res);
        }
    }
}
