﻿using System;
using System.Globalization;
using System.Security.Cryptography.X509Certificates;
using ASP.NET._2.Kuchik.Day6;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CustomerTest
{
    [TestClass]
    public class CustomerTest
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestConstructorWithParamForName()
        {
            //Arrange
            Customer customer;
            string name = null;
            string phone = "234";
            decimal i = 6;
            
            //Act
            customer = new Customer(name, phone, i);
           
            //Assert
            
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestConstructorWithParamForPhone()
        {
            //Arrange
            Customer customer;
            string name = "234";
            string phone = null;
            decimal i = 6;

            //Act
            customer = new Customer(name, phone, i);

            //Assert

        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestTostringWithFormat()
        {
            //Arrange
           
            string formt = null;
            Customer customer = new Customer();

            //Act
            customer.ToString(formt);

            //Assert
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestTostringWithAllParametrForFormat()
        {
            //Arrange

            string formt = null;
            Customer customer = new Customer();
            //Act
            customer.ToString(formt,  CultureInfo.CurrentCulture);

            //Assert
        }

        [TestMethod]
       
        public void TestTostringWithAllParamets()
        {
            //Arrange

            string formt = "ncr";
            string res;
            Customer customer = new Customer("Andrei","+3",345);
            //Act
            res =  customer.ToString(formt, CultureInfo.CurrentCulture);
            
            //Assert
            Assert.AreEqual("Customer record: Andrei, +3, 345", res);
        }

        [TestMethod]
        public void TestTostringWithAllParametsForN()
        {
            //Arrange
            string formt = "n";
            string res;
            Customer customer = new Customer("Andrei", "+3", 345);
            //Act
            res = customer.ToString(formt, CultureInfo.CurrentCulture);

            //Assert
            Assert.AreEqual("Customer record: Andrei", res);
        }

        [TestMethod]
        public void TestTostringWithAllParametsForNC()
        {
            //Arrange
            string formt = "nc";
            string res;
            Customer customer = new Customer("Andrei", "+3", 345);
            //Act
            res = customer.ToString(formt, CultureInfo.CurrentCulture);

            //Assert
            Assert.AreEqual("Customer record: Andrei, +3", res);
        }

        [TestMethod]
        public void TestTostringWithAllParametsForRC()
        {
            //Arrange
            string formt = "cR";
            string res;
            Customer customer = new Customer("Andrei", "+3", 345);
            //Act
            res = customer.ToString(formt, CultureInfo.CurrentCulture);

            //Assert
            Assert.AreEqual("Customer record: +3, 345", res);
        }

        [TestMethod]
        public void TestTostringWithAllParametsForC()
        {
            //Arrange
            string formt = "C";
            string res;
            Customer customer = new Customer("Andrei", "+3", 345);
            //Act
            res = customer.ToString(formt, CultureInfo.CurrentCulture);

            //Assert
            Assert.AreEqual("Customer record: +3", res);
        }

        public void TestTostringWithAllParametsForR()
        {
            //Arrange
            string formt = "r";
            string res;
            Customer customer = new Customer("Andrei", "+3", 345);
            //Act
            res = customer.ToString(formt, CultureInfo.CurrentCulture);

            //Assert
            Assert.AreEqual("Customer record: 345", res);
        }
    }
}
