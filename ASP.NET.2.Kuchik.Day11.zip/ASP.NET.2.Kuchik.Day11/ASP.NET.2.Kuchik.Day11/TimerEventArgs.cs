﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day11
{
    public class TimerEventArgs:EventArgs
    {
        #region Filds
        private readonly int seconds;
        #endregion

        #region Constructor
        public TimerEventArgs(int seconds) {
            this.seconds = seconds;
        }
        #endregion

        #region Properties
        public int Seconds {get {return seconds;}}
#endregion
    }
}
