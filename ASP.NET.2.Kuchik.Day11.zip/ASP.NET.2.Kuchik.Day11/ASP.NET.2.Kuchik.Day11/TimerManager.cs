﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day11
{
    public class TimerManager
    {
        #region Event
        public event EventHandler<TimerEventArgs> NewTimer = delegate { };
#endregion

        #region Public method
        /// <summary>
        /// translates information in the event
        /// </summary>
        /// <param name="seconds"></param>
        public void SimulateNewTimer(int seconds)
        {
            if (seconds < 0)
            {
                throw new ArgumentException();
            }
            
            Thread.Sleep(seconds * 1000);
            OnNewTimer(new TimerEventArgs(seconds));
        } 
#endregion

        #region Protected method
        /// <summary>
        /// method is responsible for notification
        /// </summary>
        /// <param name="seconds"></param>
        protected virtual void OnNewTimer(TimerEventArgs e)
        {
            NewTimer(this, e);
        }
#endregion
    }
}
