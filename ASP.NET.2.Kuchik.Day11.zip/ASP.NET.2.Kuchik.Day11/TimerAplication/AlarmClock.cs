﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASP.NET._2.Kuchik.Day11;

namespace TimerAplication
{
     public class AlarmClock
     {
         #region Constructor
         public AlarmClock(TimerManager timer)
        {
            timer.NewTimer += AlarmClockMessage;
        }
#endregion

         #region Public method
         /// <summary>
         /// Unregistration
         /// </summary>
         /// <param name="timer"></param>
         public void Unregistration(TimerManager timer)
        {
            timer.NewTimer -= AlarmClockMessage;
        }
#endregion

         #region Private method
         /// <summary>
         /// Get massege
         /// </summary>
         /// <param name="sender"></param>
         /// <param name="eventArgs"></param>
        private void AlarmClockMessage(Object sender, TimerEventArgs eventArgs)
        {
            Console.WriteLine("Alarm clock:");
            Console.WriteLine("dzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
        }
#endregion
       
    }
}
