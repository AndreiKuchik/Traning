﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASP.NET._2.Kuchik.Day11;

namespace TimerAplication
{
    class Program
    {
        static void Main(string[] args)
        {
            var manager = new TimerManager();
            var allarmCLock = new AlarmClock(manager);
            var man = new Man(manager);
            try
            {
                manager.SimulateNewTimer(4);
            }
            catch (ArgumentException ex)
            {
                
                
            }
           
            man.Unregistration(manager);
            Console.WriteLine();
            try
            {
                manager.SimulateNewTimer(3);
            }
            catch (ArgumentException ex)
            {


            }
            
            Console.ReadKey();
        }
    }
}
