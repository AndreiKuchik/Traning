﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASP.NET._2.Kuchik.Day11;

namespace TimerAplication
{
    public class Man
    {
        #region Constructor
        public Man(TimerManager timer)
        {
            timer.NewTimer += ManMessage;
        }
#endregion

        #region Public method
        /// <summary>
        /// Unregistration
        /// </summary>
        /// <param name="timer"></param>
        public void Unregistration(TimerManager timer)
        {
            timer.NewTimer -= ManMessage;
        }
        #endregion

        #region Private Method
        /// <summary>
        /// Get massege
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="eventArgs"></param>
        private void ManMessage(Object sender, TimerEventArgs eventArgs)
        {
            Console.WriteLine("Man say:");
            Console.WriteLine(" I waited " + eventArgs.Seconds + " second!");
        }
#endregion
       
    }
}
