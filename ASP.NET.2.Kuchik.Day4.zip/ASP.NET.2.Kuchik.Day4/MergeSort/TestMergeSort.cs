﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MethodsForMergeSort;


namespace MergeSort
{
    class TestMergeSort
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter quantity elements of array");
            int count = new Int32();
            bool flag = true;
           
            while (flag)
            {
                try
                {
                     count = Int32.Parse(Console.ReadLine());
                     flag = false;
                }
                catch (FormatException exception)
                {
                    Console.WriteLine("Error! Please repeat entry");
                }
            }
            int[] array = new int[count];
            WriteArray(array);

            MethodsForSort.MargeSort(array);
            DisplayArray(array);


            
            Console.ReadKey();
        }

        static private void DisplayArray(int [] array)
        {
            for (int i =0; i<array.Length;i++)
            {
                Console.Write(array[i]+" ");
            }
        }

        private static void WriteArray(int[] array)
        {
            bool flag;
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine("Enter {0} element", i + 1);
                flag = false;
                while (!flag)
                {
                    try
                    {
                        array[i] = Int32.Parse(Console.ReadLine());
                        flag = true;
                    }
                    catch (FormatException exception)
                    {
                        Console.WriteLine("Error! Please repeat entry");
                    }
                }
            }
            
        }
    }
}
