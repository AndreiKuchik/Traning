﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GenerateQueue
{

    public class MyQueue<T>
    {
        #region Fields
        private T[] array;
        private int size;
        private const int defaultCapacity = 10;
        private int capacity;
        private int head;
        private int tail;
        #endregion

        #region Public Methods
       
        /// <summary>
        /// Create queue, size on default ;
        /// </summary>
        public MyQueue()
        {
            capacity = defaultCapacity;
            this.array = new T[defaultCapacity+1];
            this.size = 0;
            this.head = defaultCapacity+1;
            this.tail = 0;
        }

        /// <summary>
        /// Create queue, size set;
        /// </summary>
        /// /// <param name="cap"> size of queue</param>
        public MyQueue(int cap)
        {
            capacity = cap;
            this.array = new T[cap + 1];
            this.size = 0;
            this.head = cap + 1;
            this.tail = 0;
        }
        /// <summary>
        /// this method checks the queue is empty
        /// </summary>
        /// <returns>Извлечённый элемент.</returns>
        public bool isEmpty() //проверка на пустоту
        {
            return size == 0;
        }

        /// <summary>
        /// this method adds the new element in queue
        /// </summary>
        /// <param name="newElement"> new element</param>
        public void Enqueue(T newElement)
        {
            if (this.head == this.tail+1)
            {

                throw new InvalidOperationException();
            }
            array[tail++] = newElement;
            tail = tail%(capacity + 1);
            size++;
            
        }

        /// <summary>
        /// this method extracts head of queue
        /// </summary>
        /// <returns>head of queue</returns>
        public T Dequeue()
        {
            if (head %(capacity+1) == tail )
            {
                throw new InvalidOperationException();
            }
            head = head%(capacity + 1);
            size--;
            return array[head++];
        }

        /// <summary>
        /// this method returns head of queue
        /// </summary>
        /// <returns>head of queue</returns>
         public T Peek()
        {
            if (size == 0)
                throw new InvalidOperationException();
            head = head % (capacity + 1);
            return array[head];
        }
        #endregion
     
        #region Properties
         
         public int Count
         {
             get
             {
                 return this.size;
             }
         }
         #endregion

    }
   
}

