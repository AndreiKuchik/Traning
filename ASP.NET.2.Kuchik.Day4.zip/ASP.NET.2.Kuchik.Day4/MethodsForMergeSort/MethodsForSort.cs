﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsForMergeSort
{
    public class MethodsForSort
    {

        /// <summary>
        /// this method divides elements of array
        /// </summary>
        /// <param name="array"> not sorted array</param>
     
        static public void MargeSort(int[] items)
        {
            if (items.Length <= 1)
            {
                return;
            }

            int leftSize = items.Length/2;
            int rightSize = items.Length - leftSize;

            int[] left = new int[leftSize];
            int[] right = new int[rightSize];

            Array.Copy(items, 0, left,0, leftSize);
            Array.Copy(items, leftSize, right,0,rightSize);

            MargeSort(left);
            MargeSort(right);

            Merge(items,left,right);

        }

        /// <summary>
        /// this method  compare and merge elements of array
        /// </summary>
        /// <param name="array"> not sorted array</param>
       /// <param name="left"> left array</param>
       /// <param name="right"> right array</param>
        static private void Merge(int[] items, int[] left, int [] right)
        {
            int leftIndex = 0;
            int rightIndex = 0;
            int targetIndex = 0;
            int remaining = left.Length + right.Length;

            while (remaining > 0)
            {
                if (leftIndex >= left.Length)
                {
                    items[targetIndex] = right[rightIndex++];
                }
                else if (rightIndex >= right.Length)
                {
                    items[targetIndex] = left[leftIndex++];
                }
                else if (left[leftIndex].CompareTo(right[rightIndex])<0)
                {
                    items[targetIndex] = left[leftIndex++];
                }
                else
                {
                    items[targetIndex] = right[rightIndex++];
                }
                targetIndex++;
                remaining--;
            }
        }
    }
}
