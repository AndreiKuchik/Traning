﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenerateQueue;

namespace TestQueue
{
    class TestQueue
    {
        static void Main(string[] args)
        {

           MyQueue<int> f = new MyQueue<int>();
           
          
            try
            {   
                f.Enqueue(5);
                f.Enqueue(3);
                f.Enqueue(7);
                f.Enqueue(0);
                f.Enqueue(6);
                f.Dequeue();
                f.Dequeue();
                f.Dequeue();
                f.Enqueue(0);
                f.Enqueue(0);
                f.Enqueue(6);
                Console.WriteLine(f.Count);
                Console.WriteLine(f.Peek());
            }
            catch (InvalidOperationException ex)
            {
              Console.WriteLine("Queue is empty!");
            }

          
           
            Console.ReadKey();
        }
    }
}
