﻿using System;
using MethodEuclidAndBinary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MethodEuclidAndBinaryTests
{
    [TestClass]
    public class MethodsTests
    {
         [TestMethod]
        public void EuclidFor_4_8()
        {
            // arrange
            DateTime start = DateTime.Now;
            int x = 4;
            int b = 8;
            TimeSpan sp = DateTime.Now -start ;
            //Act
            int result = EuklidBinary.Euklid(x, b, out sp);
            //Assert
            Assert.AreEqual(4, result);
        }

         [TestMethod]
        public void EuclidFor_55_13()
        {
            // arrange
            DateTime start = DateTime.Now;
            int x = 55;
            int b = 13;
            TimeSpan sp = DateTime.Now - start;
            //Act
            int result = EuklidBinary.Euklid(x, b, out sp);
            //Assert
            Assert.AreEqual(1, result);
        }

         [TestMethod]
         public void EuclidFor_36_104()
         {
             // arrange
             DateTime start = DateTime.Now;
             int x = 36;
             int b = 104;
             TimeSpan sp = DateTime.Now - start;
             //Act
             int result = EuklidBinary.Euklid(x, b, out sp);
             //Assert
             Assert.AreEqual(4, result);
         }

        [TestMethod]
         public void EuclidFor_36_104_18()
         {
             // arrange
             DateTime start = DateTime.Now;
             int x = 36;
             int b = 104;
             int c = 18;
             TimeSpan sp = DateTime.Now - start;
             //Act
             int result = EuklidBinary.Euklid(x, b,c, out sp);
             //Assert
             Assert.AreEqual(2, result);
         }

        [TestMethod]
        public void EuclidFor_50_100_20()
        {
            // arrange
            DateTime start = DateTime.Now;
            int x = 50;
            int b = 100;
            int c = 20;
            TimeSpan sp = DateTime.Now - start;
            //Act
            int result = EuklidBinary.Euklid(x, b, c, out sp);
            //Assert
            Assert.AreEqual(10, result);
        }

         [TestMethod]
        public void EuclidFor_params()
        {
            // arrange
            DateTime start = DateTime.Now;
            int[] n = new[] {6, 8, 4, 10, 16};
            TimeSpan sp = DateTime.Now - start;
            //Act
            int result = EuklidBinary.Euklid(out sp,n);
            //Assert
            Assert.AreEqual(2, result);
        }


        [TestMethod]
         public void BinaryFor_6_12()
         {
             // arrange
             DateTime start = DateTime.Now;
             int x = 6;
             int b = 12;
             TimeSpan sp = DateTime.Now - start;
             //Act
             int result = EuklidBinary.Binary(x, b, out sp);
             //Assert
             Assert.AreEqual(6, result);
         }

        [TestMethod]
        public void Binary_53_111()
        {
            // arrange
            DateTime start = DateTime.Now;
            int x = 53;
            int b = 111;
            TimeSpan sp = DateTime.Now - start;
            //Act
            int result = EuklidBinary.Euklid(x, b, out sp);
            //Assert
            Assert.AreEqual(1, result);
        }

       
        [TestMethod]
        public void Binary_36_104_18()
        {
            // arrange
            DateTime start = DateTime.Now;
            int x = 36;
            int b = 104;
            int c = 18;
            TimeSpan sp = DateTime.Now - start;
            //Act
            int result = EuklidBinary.Binary(x, b, c, out sp);
            //Assert
            Assert.AreEqual(2, result);
        }

        [TestMethod]
        public void Binry_50_100_20()
        {
            // arrange
            DateTime start = DateTime.Now;
            int x = 50;
            int b = 100;
            int c = 20;
            TimeSpan sp = DateTime.Now - start;
            //Act
            int result = EuklidBinary.Binary(x, b, c, out sp);
            //Assert
            Assert.AreEqual(10, result);
        }

        [TestMethod]
        public void BinaryFor_params()
        {
            // arrange
            DateTime start = DateTime.Now;
            int[] n = new[] { 6, 24, 36, 12, 18 };
            TimeSpan sp = DateTime.Now - start;
            //Act
            int result = EuklidBinary.Binary(out sp, n);
            //Assert
            Assert.AreEqual(6, result);
        }
    }
}
