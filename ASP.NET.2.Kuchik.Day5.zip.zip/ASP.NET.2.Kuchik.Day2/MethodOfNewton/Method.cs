﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOfNewton
{
    public class Method
    {
        #region Public Method
        /// <summary>
        ///  This method realises method Newton
        /// </summary>
        /// <param name="degree">this is dgree of number</param>
        /// <param name="number"> Number for explore.</param>
        /// <param name="accuracy"> this is accuracy of number.</param>
        /// <returns>Result of research</returns>
        public static double MySqrt(double degree, double numder, double accuracy)
        {
            double x0 = numder/degree;
            double xk = 1/degree*((degree - 1)*x0 + numder/MyPow(x0,(int)(degree - 1)));

            while (Math.Abs(xk - x0) > accuracy)
            {
                x0 = xk;
                xk = 1 / degree * ((degree - 1) * x0 + numder / MyPow(x0, (int)degree - 1));
            }
            return Math.Round(xk, 4);
        }
        #endregion

        #region Private Method
        /// <summary>
        ///  This method raises the degree of numbers
        /// </summary>
        ///  /// <param name="x">number raise to the power.</param>
        /// <param name="degre"> this is dgree of number.</param>
        /// <returns>Number in degree</returns>
        public static double MyPow(double x, int degre)
        {
            double result = 1;
            for (int i = 0; i < degre; i++) result *= x;
            return Math.Round(result, 4);
            
        }
        #endregion

    }
}
