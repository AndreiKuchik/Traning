﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MethodEuclidAndBinary;

namespace ConsoleApplicationEuklid
{
    class Program
    {
        static void Main(string[] args)
        {
            int a =0;
            int b =0;
            int result;
            int result1;
            TimeSpan sp;
            bool flag = true;
            while (flag)
            { 
                Console.WriteLine("Enter first number");
                try
                {  
                    a = Int32.Parse(Console.ReadLine());
                    flag = false;
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Input Error!");
                }
            }
            flag = true;

            while (flag)
            {  
                Console.WriteLine("Enter second number");
                try
                { 
                    b= Int32.Parse(Console.ReadLine());
                    flag = false;
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Input Error!");
                }
            }
            flag = true;
            result = EuklidBinary.Euklid(a, b, out sp);
            Console.WriteLine("Result of method Euklid " + result + " runtime "+ sp);
            result1 = EuklidBinary.Binary(a, b, out sp);
            Console.WriteLine("Result of method Binary " + result1 + " runtime " + sp);
            Console.ReadKey();

        }
    }
}
