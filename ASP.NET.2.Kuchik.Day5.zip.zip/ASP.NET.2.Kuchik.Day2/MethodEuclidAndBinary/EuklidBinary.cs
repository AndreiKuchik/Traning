﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodEuclidAndBinary
{
    public class EuklidBinary
    {
        #region Public Metods

        #region Euklid Metods
        /// <summary>
        ///  This method realises algorithm Euklid for finding NOD
        /// </summary>
        /// <param name="a">this is first number</param>
        /// <param name="b"> this second number </param>
       /// <returns>NOD</returns>
        public static int Euklid(int a, int b, out TimeSpan sp)
        {
            DateTime start = DateTime.Now;
            while (a!=0 && b!=0)
            {
                if (a > b)
                {
                    a = a%b;
                }
                else
                {
                    b = b%a;
                }
            }
            sp = DateTime.Now - start;
            return (a+b);
        }
        /// <summary>
        ///  This method overrides realization algorithm Euklid for finding NOD
        /// </summary>
        public static int Euklid(int a, int b, int c, out TimeSpan sp)
        {
            int res;
            TimeSpan sp1;
            res = Euklid(a, b, out sp);
            res = Euklid(res, c,out sp1);
            sp +=sp1;
            return res ;
        }
        /// <summary>
        ///  This method overrides realization algorithm Euklid for finding NOD
        /// </summary>
        public static int Euklid( out TimeSpan sp, params int[] numbers)
        {
            int res;
            TimeSpan sp1;
            res = Euklid(numbers[0], numbers[1], out sp);
            for (int i = 2; i < numbers.Length; i++)
            {
                
                res= Euklid(numbers[i],res, out sp1) ;
                sp += sp1;
            }
           return res;
        }
        #endregion


        #region Binary Metods
        /// <summary>
        ///  This method realises Binary algorithm for finding NOD
        /// </summary>
        /// <param name="a">this is first number</param>
        /// <param name="b"> this second number </param>
        /// <returns>NOD</returns>
        public static int Binary(int a, int b, out TimeSpan span)
        {
            DateTime start1 = DateTime.Now;
            int k = 1;
            while ((a != 0) && (b != 0))
            {
                
                while ((a % 2 == 0) && (b % 2 == 0))
                {
                    a /= 2;
                    b /= 2;
                    k *= 2;
                }
                while (a % 2 == 0) a /= 2;
                while (b % 2 == 0) b /= 2;
                if (a >= b)
                {
                    a -= b;
                }
                else 
                {b -= a;}
                
            }
           DateTime finish = DateTime.Now;
           span = finish - start1;
           return b * k;
        }
        /// <summary>
        ///  This method realises overrides Binary algorithm for finding NOD
        /// </summary>
        public static int Binary(int a, int b, int c, out TimeSpan sp)
        {
            int res;
            TimeSpan sp1;
            res = Binary(a, b, out sp);
            res = Binary(res, c, out sp1);
            sp += sp1;
            return res;
        }
        /// <summary>
        ///  This method realises overrides Binary algorithm for finding NOD
        /// </summary>
        public static int Binary(out TimeSpan sp, params int[] numbers)
        {
            int res;
            TimeSpan sp1;
            res = Binary(numbers[0], numbers[1], out sp);
            for (int i = 2; i < numbers.Length; i++)
            {

                res = Binary(numbers[i], res, out sp1);
                sp += sp1;
            }
            return res;
        }
#endregion


        #endregion
    }
}
