﻿using System;
using MethodOfNewton;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MethodOfNewtonTests
{
    [TestClass]
    public class NewtonTests
    {
        [TestMethod]
        public void Pow_4_vo2stepeni()
        {
            // arrange
          
            double x  = 4;
            int degree = 2;
            //Act
            double result = Method.MyPow(x, degree);
            //Assert
            Assert.AreEqual(16, result);
        }

         [TestMethod]
        public void Pow_5_v3stepeni()
        {
            // arrange

            double x = 5;
            int degree = 3;
            //Act
            double result = Method.MyPow(x, degree);
            //Assert
            Assert.AreEqual(125, result);
        }

         [TestMethod]
         public void Pow_vesh8_v4stepeni()
         {
             // arrange

             double x = 8.67;
             int degree = 4;
             //Act
             double result = Method.MyPow(x, degree);
             //Assert
             Assert.AreEqual(Math.Round(Math.Pow(8.67,4), 4), result);
         }

         [TestMethod]
         public void SQRT_25_vKorne2stepeni()
         {
             // arrange

             double number = 25;
             double degree = 2;
             //Act
             double result = Method.MySqrt(degree, number, 0.0001);
             //Assert
             Assert.AreEqual(5, result);
         }

         [TestMethod]
         public void SQRT_27_vKorne3stepeni()
         {
             // arrange
             double number = 27;
             double degree = 3;
             double res = 3.0;
             //Act
             double result = Method.MySqrt(degree, number,0.0001);
             //Assert
             Assert.AreEqual(res, result);
         }
    }
    
}
