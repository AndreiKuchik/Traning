﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MethodOfNewton;

namespace MethodOfNewtonCA
{
    class Program
    {
        static void Main(string[] args)
        {
            double number=0;
            double degree=0;
            bool flag = true;
            while (flag)
            {
                Console.WriteLine("Enter the number");
                try
                {
                    number = double.Parse(Console.ReadLine());
                    flag = false;
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Input Error!");
                }
            }
            flag = true;
            while (flag)
            { 
                Console.WriteLine("Enter the degree");
                try
                {
                     degree = double.Parse(Console.ReadLine());
                    flag = false;
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Input Error!");
                }
            }
            
            double result = Method.MySqrt(degree, number, 0.0001);
            
            Console.WriteLine("MySqrt "+ result);
            Console.WriteLine("Math.Pow " + Math.Pow(number, 1/degree));
            Console.ReadKey();

        }
    }
}
