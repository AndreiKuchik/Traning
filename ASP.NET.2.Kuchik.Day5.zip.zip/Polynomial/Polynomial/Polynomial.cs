﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polynomial
{
    public  class Polynomial
    {
        #region Private Fields
        private double[] coefficients = null;
        private double this[int index]
        {
            get
            {
                if (index < 0 || index > Degree)
                    throw new ArgumentOutOfRangeException();
                return coefficients[index];
            }
        }
        #endregion

        #region Public Fields
        public int Degree { get; set; }
        #endregion

        #region Constructors
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="coefficients">This is coefficients of polynomial</param>
        public Polynomial(params double[] coefficients)
        {
            if (coefficients == null)
                throw new ArgumentNullException();

            this.coefficients = new double[coefficients.Length];

            for (int i = 0; i < coefficients.Length; i++)
                this.coefficients[i] = coefficients[i];

            Degree = coefficients.Length - 1;
        }
        
        public Polynomial(Polynomial obj) : this(obj.coefficients) { }
        #endregion

        #region Public Methods
        public override string ToString()
        {
          StringBuilder polynomialBuilder = new StringBuilder();
           polynomialBuilder.Append("Polynomial: ");
            for(int i = Degree; i >= 0; i--) {
              
                if (i != coefficients.Length - 1)
                    polynomialBuilder.Append(" + ");
                polynomialBuilder.Append(coefficients[i]);
                if (i != 0)
                { 
                    polynomialBuilder.Append("*x^");
                    polynomialBuilder.Append(i);
            }

            }
            

            return polynomialBuilder.ToString() ;
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;
            Polynomial polynomial = obj as Polynomial; // возвращает null если объект нельзя привести к типу Money
            if (polynomial as Polynomial == null)
                return false;

            return Equals(polynomial);
        }

        public bool Equals(Polynomial obj) {

            if (obj == null) 
                if ( coefficients.Length != obj.coefficients.Length ) {
                return false;
            }
            for ( int i = 0; i < this.coefficients.Length; i++ ) {
                if ( this.coefficients[ i ] != obj.coefficients[ i ] ) 
                {
                    return false;
                }
            }
            return true;
                
        }
        public override int GetHashCode()
        {
            int hashcode = 0;
            for (int i = 0; i < coefficients.Length; i++)
            {
                 hashcode = hashcode + (int)coefficients[i];
            }
            hashcode = hashcode * Degree;
            return hashcode;
        }
    
       /// <summary>
        /// Calculate the value of polynomial with variable value
        /// </summary>
        /// <param name="value">Polynomial's variable</param>
        /// <returns>Value of polynomial</returns>
        public double Calculate(double value) {
            double result = 0;
            for( int i = 0; i <= Degree; i++ ) 
                result += Math.Pow(value, i) * coefficients[ i ];
            return result;
        }

        #endregion

        #region Operators
        /// <summary>
        /// Adds monomial with polynomial
        /// </summary>
        /// <param name="a">polynomial</param>
        /// <param name="monomial">monomial</param>
        /// <returns>New Polynomial</returns>
        public static  Polynomial operator +(Polynomial a, double monomiel)
        {
            Polynomial resultPoly = new Polynomial(a.coefficients);
            resultPoly.coefficients[0] = +monomiel;
            return resultPoly;
            
        }
        public static  Polynomial operator +(double monomiel, Polynomial polynomial)
        {
            
            return polynomial+monomiel;
            
        }

        /// <summary>
        /// Calculate the sum of two polynomials 
        /// </summary>
        /// <param name="polynomial1">The first polynomial</param>
        /// <param name="polynomial2">The second polynomial</param>
        /// <returns>The sum of two polynomials</returns>
        public static Polynomial operator +(Polynomial polynomial1, Polynomial polynomial2) 
        {
            if (polynomial1 == null)
                throw new ArgumentNullException();
            if (polynomial2 == null)
                throw new ArgumentNullException();
            int newDegree = Math.Max(polynomial1.Degree, polynomial2.Degree);
            double[] tempArray = new double[newDegree + 1];

            for (int i = 0; i <= newDegree; i++) {
                double temp = 0;
                if (i <= polynomial1.Degree)
                    temp += polynomial1.coefficients[i];
                if (i <= polynomial2.Degree)
                    temp += polynomial2.coefficients[i];
                tempArray[i] = temp;
            }
            return new Polynomial(tempArray);
        }
       
        /// <summary>
        /// multiplied by the number of polynomial
        /// </summary>
        /// <param name="polynomial">polynomial</param>
        /// <param name="k">number</param>
        /// <returns>Polynomial multiplied by a constant</returns>
        public static Polynomial operator *( Polynomial polynomial, double k )
        {
            double[] tempArray = new double[polynomial.Degree + 1];

            for (int i = 0; i < polynomial.coefficients.Length; i++)
            {
                tempArray[i] =polynomial.coefficients[i] * k;
            }

             return new Polynomial(tempArray);
        }

        public static Polynomial operator *( double k , Polynomial polynomial )
        {
            
             return  polynomial*k;
        }
 
        /// <summary>
        /// Multiplies two polynomials
        /// </summary>
        /// <param name="polynomial1">The first polynomial</param>
        /// <param name="polynomial2">The second polynomial</param>
        /// <returns>New polynomial</returns>
        public static Polynomial operator *( Polynomial polynomial1, Polynomial polynomial2 ) {
            int itemsCount = polynomial1.coefficients.Length + polynomial2.coefficients.Length - 1;
            var result = new double[itemsCount];
            for ( int i = 0; i < polynomial1.coefficients.Length; i++ ) {
                for ( int j = 0; j < polynomial2.coefficients.Length; j++ ) {
                    result[ i + j ] += polynomial1[ i ] * polynomial2[ j ];
                }
            }
 
            return new Polynomial( result );
        }

        /// <summary>
        /// compares two polynomials
        /// </summary>
        
        public static bool operator ==(Polynomial polynomial1, Polynomial polynomial2) {
            if (polynomial1 == null || polynomial2 == null)
                return false;
            if (polynomial1.Degree!= polynomial2.Degree)
            {
                return false;
            }
            
           return (ReferenceEquals(polynomial1, polynomial2));
           
        }

        /// <summary>
        /// compares two polynomials
        /// </summary>
        public static bool operator !=(Polynomial polynomial1, Polynomial polynomial2)
        {
       
            return !(polynomial1 == polynomial2);
        }


        /// <summary>
        /// Subtracts the number of the polynomial
        /// </summary>
        /// <param name="polynomial">polynomial</param>
        /// <param name="monomiel">monomiel</param>
        /// <returns>New polynomial</returns>
          public static  Polynomial operator -(Polynomial polynomial, double monomiel)
        {
            Polynomial resultPoly = new Polynomial(polynomial.coefficients);
            resultPoly.coefficients[0] = -monomiel;
            return resultPoly;
            
        }
         public static  Polynomial operator -(double monomiel,Polynomial polynomial )
        {
          
            return polynomial - monomiel;
            
        }

         /// <summary>
         /// Calculate the difference of two polynomials 
         /// </summary>
         /// <param name="polynomial1">The first polynomial</param>
         /// <param name="polynomial2">The second polynomial</param>
         /// <returns>The difference of two polynomials</returns>
          public static Polynomial operator -( Polynomial polynomial1, Polynomial polynomial2 ) {
            int itemsCount = Math.Max( polynomial1.coefficients.Length, polynomial2.coefficients.Length );
            var result = new double[itemsCount];
            for ( int i = 0; i < itemsCount; i++ ) {
                double a = 0;
                double b = 0;
                if ( i < polynomial1.coefficients.Length ) {
                    a = polynomial1[ i ];
                }
                if ( i < polynomial2.coefficients.Length ) {
                    b = polynomial2[ i ];
                }
                result[ i ] = a - b;
            }
            return new Polynomial( result );
          }


        #endregion

    }
}
