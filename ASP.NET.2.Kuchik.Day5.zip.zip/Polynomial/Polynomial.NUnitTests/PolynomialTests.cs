﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Polynomial;
using System.Threading.Tasks;

namespace Polynomial.NUnitTests
{
    public class PolynomialTests
    {
        public IEnumerable<TestCaseData> ExceptionTestDatas
        {
            get
            {
                yield return new TestCaseData(null).Throws(typeof(ArgumentNullException));
            }
        }
        [Test, TestCaseSource("ExceptionTestDatas")]
        public void Constructors_Exceptions_Test(double[] array)
        {
            Polynomial polynomial = new Polynomial(array);
        }

         public IEnumerable<TestCaseData> TestToString {
            get {
                yield return new TestCaseData(new double[] { 1 }).Returns("Polynomial: 1");
                yield return new TestCaseData(new double[] { 1, 2,3 }).Returns("Polynomial: 3*x^2 + 2*x^1 + 1");
            }
        }

        [Test, TestCaseSource("TestToString")]
        public string ToString_Test(double[] coeffArray)
        {
            return new Polynomial(coeffArray).ToString();
        }

        
        // Далее моя visual studio перестала корректно работать и при любом  новом тесте выбрасывает из проекта;
        public IEnumerable<TestCaseData> EqualsTestData
        {
            get
            {
                yield return new TestCaseData(new Polynomial(new double[] { 1, 2, 3 }));
                
            }
        }
        [Test, TestCaseSource("EqualsTestData")]
        public void Equals_Test(Polynomial a)
        {
            
            Assert.AreEqual(a.Equals(a), true);
            //Polynomial c = new Polynomial(new double[] { 4, 5, 6, 7 });
            
        }


    }

}
