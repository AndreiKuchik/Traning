﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_Stack
{
    public class StringStack
    {
        private  string [] items;
        private int count;
        const int n = 5;
        public StringStack()
        {
            items = new string[n];
        }
        public StringStack(int length)
        {
            items = new string[length];
        }

        public void Push(string item)
        {

            if (count == items.Length)
                NewLength(items.Length + 5);

            items[count++] = item;
        }
        public string Pop()
        {

            if (count == 0)
                throw new Exception("Стек пуст!");
            string item = items[--count];
            items[count] = null;

            if (count > 0 && count < items.Length - 5)
                NewLength(items.Length - 5);

            return item;
        }
        public string Peek()
        {
            return items[count - 1];
        }

        private void NewLength(int max)
        {
            string[] tempItems = new string[max];
            for (int i = 0; i < count; i++)
                tempItems[i] = items[i];
            items = tempItems;
        }

        public void Display()
        {
            foreach (var i in items)
                Console.Write("\t" + i);
        }
    }


}
