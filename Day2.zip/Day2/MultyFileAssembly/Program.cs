﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                
                StringStack stack = new StringStack(8);
                stack.Push("ПРивет");
                stack.Push("Hello");
                stack.Push("Hi");
                stack.Push("Far");

                Console.WriteLine("Удаляем элемент из верхушки стека");
                var head = stack.Pop();
                Console.WriteLine(head);

                Console.WriteLine("Извлекаем элемент из верхушки стека");
                head = stack.Peek();
                Console.WriteLine(head);

                Console.WriteLine("Стек:");
                stack.Display();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            Console.Read();
        }
    }
}
