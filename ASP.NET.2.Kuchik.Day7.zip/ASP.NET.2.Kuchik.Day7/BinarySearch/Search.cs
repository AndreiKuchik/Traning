﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinarySearch
{
    public static class Search
    {

        #region Public Methods
        public static bool Searching<T>(T[] array, T sought, Comparison<T> comparison)
        {
            if (array == null)
            {
                throw new ArgumentNullException(" Array is null");
            }
            if (sought == null)
            {
                throw new ArgumentNullException(" Sought is null");
            }
            return Searching<T>(array, sought, new MyComparer<T>(comparison));
        }

        public static bool Searching<T>(T[] array, T sought)
        {
            if (array == null)
            {
                throw new ArgumentNullException(" Array is null");
            }
            if (sought == null)
            {
                throw new ArgumentNullException(" Sought is null");
            }
            if (sought is IComparable)
            {
                IComparer<T> comparer = Comparer<T>.Default;
                return BinarySearch(array, sought, comparer);
            }
            else
                throw new InvalidOperationException("Specified type does't implement IComparable<" + sought.GetType() + "> interface");
        }

        
        public static bool Searching<T>(T[] array, T sought, IComparer<T> comparer)
        {
            if (array == null)
            {
                throw new ArgumentNullException(" Array is null");
            }
            if (sought == null)
            {
                throw new ArgumentNullException(" Sought is null");
            }
            if (comparer == null && typeof(T).GetInterface("IComparable`1") != null || typeof(T).GetInterface("IComparable") != null)
            {
                comparer = Comparer<T>.Default;
            }
            else throw new ArgumentException();

            return BinarySearch(array, sought, comparer);
        }

#endregion

#region Private Methods
        /// <summary>
        /// Search element in sorted array and returns valid index of found element.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="array">Sorted array of <see cref="T"/>.</param>
        /// <param name="sought">Element to search.</param>
        /// <param name="comparer"></param>
        /// <returns>Index element  in array or negative number if not found.</returns>
        public static bool BinarySearch<T>(T[] array, T sought, IComparer<T> comparer)
        {
            int left = 0;
            int right = array.Length - 1;
            int mid = right / 2;

            while (left <= right)
            {
                int result = comparer.Compare(array[mid], sought);
                if (result == 0)
                    return true;
                else if (result < 0)
                {
                    left = mid + 1;
                    mid = (left + right) / 2;
                }
                else if (result > 0)
                {
                    right = mid - 1;
                    mid = (left + right) / 2;
                }
            }
            return false;
         }
       


#endregion

#region Private Class
        private class MyComparer<T> : IComparer<T>
        {
            private Comparison<T> comparison;

            public MyComparer(Comparison<T> comparison)
            {
                this.comparison = comparison;
            }
            public int Compare(T x, T y)
            {
                return this.comparison(x, y);
            }
        }
#endregion
    }
}
