﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using BinarySearch;

namespace BinarySearch.NUnitTests
{
    [TestFixture]
    public class SearchTests
    {

        private int[] array = {-4, 1, 4, 7, 12, 56};
        private string[] str = {"An", "Ban","Ce", "Ve"};


        public static IEnumerable<TestCaseData> TestIntDatasSearch
        {
            get
            {
                yield return new TestCaseData(-2).Returns(false);
                yield return new TestCaseData(54).Returns(false);
                yield return new TestCaseData(6).Returns(false);
                yield return new TestCaseData(4).Returns(true);
                yield return new TestCaseData(1).Returns(true);
            }
        }

        public IEnumerable<TestCaseData> TestStringDatasSearch
        {
            get
            {
                yield return new TestCaseData("Fd").Returns(false);
                yield return new TestCaseData("An").Returns(true);
                yield return new TestCaseData("Has").Returns(false);
                yield return new TestCaseData("Ce").Returns(true);
               
            }
        }

        [Test, TestCaseSource("TestIntDatasSearch")]
        public bool BinarySearchTest_Int(int x)
        {
            return Search.Searching(array, x);
        }

        [Test, TestCaseSource("TestStringDatasSearch")]
        public bool BinarySearchTest_String(string x)
        {
            return Search.Searching(str, x);
        }
    }

}
