﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day7
{
   public class Triangle: Shape
    {
        #region Public Filds
        public double SideA { get; private set; }
        public double SideB { get; private set; }
        public double SideC { get; private set; }

#endregion

        #region Constructors
        public Triangle()
        {
            SideA = 2;
            SideB = 3;
            SideC = 4;
        }

        public Triangle(double a, double b, double c)
        {
            if (a < epsilon)
            {
                throw new ArgumentException();
            }
            else if (b < epsilon)
            {
                throw new ArgumentException();
            }
            else if (c < epsilon)
            {
                throw new ArgumentException();
            }
            if (VerificationSides(a, b, c))
            {
                SideA = a;
                SideB = b;
                SideC = c;
            }
            else
            {
                throw new ArgumentException("This triangle does not exist");
            }
            
        }
#endregion

        #region Public Methods
        /// <summary>
        /// This method finds perimeter of shape
        /// </summary>
        /// <returns>perimeter of shape</returns>
        public override double GetPerimeter()
        {
            return SideA + SideB + SideC;
        }

        /// <summary>
        /// This method finds area of shape
        /// </summary>
        /// <returns>area of shape</returns>
        public override double GetArea()
        {
            double halfPerimeter = GetPerimeter() / 2;
            return Math.Sqrt(halfPerimeter * (halfPerimeter - SideA) * (halfPerimeter - SideB) * (halfPerimeter - SideC));
        }
#endregion

        #region Private Method
        private bool VerificationSides(double a, double b, double c)
        {
            if (a + b - c > epsilon)
            {
                if (a + c - b > epsilon)
                {
                    if (b + c - a > epsilon)
                    {
                        return true;
                    }
                }
            }
            
            return false;
        }
#endregion


    }
}
