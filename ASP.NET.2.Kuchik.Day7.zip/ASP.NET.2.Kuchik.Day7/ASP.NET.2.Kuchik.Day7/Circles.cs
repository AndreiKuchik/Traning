﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day7
{
    public class Circles:Shape
    {
        #region Public Filds
        public double Radius { get; private set; }
        #endregion

        #region Constructors
         public Circles()
        {
            Radius = 1;
        }

        public Circles(double radius)
        {
            if (radius < epsilon)
            {
                throw new ArgumentException();
            }
            else
                Radius = radius;
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// This method finds perimeter of shape
        /// </summary>
        /// <returns>perimeter of shape</returns>
        public override  double GetPerimeter()
        {
            return 2 * Math.PI * Radius;
        }

        /// <summary>
        /// This method finds area of shape
        /// </summary>
        /// <returns>area of shape</returns>
        public override double GetArea()
        {
            return Math.PI * Math.Pow(Radius, 2);
        }
#endregion
    }
}
