﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day7
{
   public class Square: Shape
    {
        #region Public Filds
        public double Side { get; private set; }
#endregion

        #region Constructors
        public Square()
        {
            Side = 1;
        }
        public Square(double side)
        {
            if (side < epsilon)
            {
               throw new ArgumentException();
            }
            else 
            Side = side;
        }
#endregion

#region Public Methods

        /// <summary>
        /// This method finds area of shape
        /// </summary>
        /// <returns>area of shape</returns>
        public override double GetArea()
        {
            return Math.Pow(Side, 2);
        }

        /// <summary>
        /// This method finds perimeter of shape
        /// </summary>
        /// <returns>perimeter of shape</returns>
        public override double GetPerimeter()
        {
            return 4*Side;
        }
#endregion
        
    }
}
