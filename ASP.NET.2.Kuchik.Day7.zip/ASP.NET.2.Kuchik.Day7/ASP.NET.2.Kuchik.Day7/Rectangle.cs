﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day7
{
    public class Rectangle: Shape
    {
        #region Public Filds
        public double  Height { get; private set; }
        public double  Width { get; private set; }
#endregion
        #region Constructors
        public Rectangle()
        {
            Height = Width = 1;
           
        }
        public Rectangle(double height, double width)
        {
            if (height < epsilon)
            {
               throw new ArgumentException();
            }
            else 
            Height = height;
            if (width < epsilon)
            {
                throw  new ArgumentException();
            }
            else
            Width = width;
        }
#endregion

        #region Public Methods

        /// <summary>
        /// This method finds area of shape
        /// </summary>
        /// <returns>area of shape</returns>
        public override double GetArea()
        {
            return Height*Width;
        }

        /// <summary>
        /// This method finds perimeter of shape
        /// </summary>
        /// <returns>perimeter of shape</returns>
        public override double GetPerimeter()
        {
            return 2 * Height + 2 * Width;
        }
#endregion
    }
}
