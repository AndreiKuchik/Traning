﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASP.NET._2.Kuchik.Day7
{
    public abstract class  Shape
    {
        #region Public Filds
        public abstract double GetArea();
        public abstract double GetPerimeter();

        public double epsilon = 0.00001;
#endregion
    }
}
