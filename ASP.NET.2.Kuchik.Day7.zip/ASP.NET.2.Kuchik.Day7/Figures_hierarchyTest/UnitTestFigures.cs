﻿using System;
using ASP.NET._2.Kuchik.Day7;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Figures_hierarchyTest
{
    [TestClass]
    public class UnitTestFigures
    {
        [TestMethod]
        public void TestForRectangleGetPerimetr()
        {
           Rectangle rectangle = new Rectangle(2,5);
            //Arrange
            double res;
            //Act 
            res = rectangle.GetPerimeter();
           //Assert
           Assert.AreEqual(14, res);
        }

        [TestMethod]
        public void TestForRectangleGetArea()
        {
            Rectangle rectangle = new Rectangle(2, 5);
            //Arrange
            double res;
            //Act 
            res = rectangle.GetArea();
            //Assert
            Assert.AreEqual(10, res);
        }



        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestForTriangleExeption()
        {
           
            //Arrange
            Triangle triangle = new Triangle(1,2,3);
            double res;
          
        }

        [TestMethod]
        public void TestForTriangleGePerimetr()
        {
            Triangle triangle = new Triangle(2,4,5);
            //Arrange
            double res;
            //Act 
            res = triangle.GetPerimeter();
            //Assert
            Assert.AreEqual(11, res);
        }

        [TestMethod]
        public void TestForTriangleGetArea()
        {
            Triangle triangle = new Triangle(2, 4, 5);
            //Arrange
            double res;
            //Act 
            res = triangle.GetArea();
            //Assert
            Assert.AreEqual(3.799671038392666, res);
        }


        [TestMethod]
        public void TestForRectangleGePerimetr()
        {
            Square square = new Square(4);
            //Arrange
            double res;
            //Act 
            res = square.GetPerimeter();
            //Assert
            Assert.AreEqual(16, res);
        }

        [TestMethod]
        public void TestForSquareGetArea()
        {
            Square square = new Square(4);
            //Arrange
            double res;
            //Act 
            res = square.GetArea();
            //Assert
            Assert.AreEqual(16, res);
        }
        
        [TestMethod]
        public void TestForCirclesGePerimetr()
        {
            Circles circles = new Circles(3);
            //Arrange
            double res;
            //Act 
            res = circles.GetPerimeter();
            //Assert
            Assert.AreEqual(18.85, Math.Round(res,3));
        }

        [TestMethod]
        public void TestForCirclesGetArea()
        {
            Circles circles = new Circles(3);
            //Arrange
            double res;
            //Act 
            res = circles.GetArea();
            //Assert
            Assert.AreEqual(28.274, Math.Round(res,3));
        }
    }
}
