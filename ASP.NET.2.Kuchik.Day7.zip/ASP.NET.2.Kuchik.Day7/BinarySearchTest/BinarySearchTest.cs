﻿using System;
using System.Collections.Generic;
using BinarySearch;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BinarySearchTest
{
    [TestClass]
    public class BinarySearchTest
    {
        private int[] array = { -4, 1, 4, 7, 12, 56 };
        private string[] str = { "An", "Ban", "Ce", "Ve" };
        [TestMethod]
        
        public void TestSearchingWith2Parametrs()
        {  
            //Arrange
            
            int search = -2;
            bool res;
           //Act 
            res = Search.Searching(array, search);
            //Assert
            Assert.AreEqual(false, res);
        }


         [TestMethod]
        public void TestSearchingWith2ParametrsTrue()
        {
            //Arrange

            int search = 1;
            bool res;
           //Act 
            res = Search.Searching(array, search);
            //Assert
            Assert.AreEqual(true, res);
        }


         [TestMethod]
         public void TestSearchingWith3ParametrsTrue()
         {
             //Arrange

             int search = 4;
             bool res;
             IComparer<Int32> comparer = Comparer<Int32>.Default;
             //Act 
             res = Search.Searching(array, search,comparer);
             //Assert
             Assert.AreEqual(true, res);
         }

         [TestMethod]
         public void TestSearchingWith3ParametrsFalse()
         {
             //Arrange

             int search = 124;
             bool res;
             IComparer<Int32> comparer = Comparer<Int32>.Default;
             //Act 
             res = Search.Searching(array, search, comparer);
             //Assert
             Assert.AreEqual(false, res);
         }

         [TestMethod]
         public void TestSearchingWith3ParametrsStr()
         {
             //Arrange

             string search = "An";
             bool res;
             IComparer<string> comparer = Comparer<string>.Default;
             //Act 
             res = Search.Searching(str, search, comparer);
             //Assert
             Assert.AreEqual(true, res);
         }

         [TestMethod]
         public void TestSearchingWith3ParametrsStrFalse()
         {
             //Arrange

             string search = "CF";
             bool res;
             IComparer<string> comparer = Comparer<string>.Default;
             //Act 
             res = Search.Searching(str, search, comparer);
             //Assert
             Assert.AreEqual(false, res);
         }

         [TestMethod]
         [ExpectedException(typeof(ArgumentNullException))]
         public void TestSearchingWith3ParametrsExeption()
         {
             //Arrange

             string search = null;
             bool res;
             IComparer<string> comparer = Comparer<string>.Default;
             //Act 
             res = Search.Searching(str, search, comparer);
             //Assert
             Assert.AreEqual(false, res);
         }



    }
}
