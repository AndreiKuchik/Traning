﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using ASP.NET._2.Kuchik.Day7;

namespace Fiqures_hierarchy.NUnitTests
{
    public class FiguresTest
    {
        #region Rectangle
        public static IEnumerable<TestCaseData> TestPerimetrDatas
        {
            get
            {
                yield return new TestCaseData(2,5).Returns(14);
                yield return new TestCaseData(3,6).Returns(18);
              
            }
        }

       [Test, TestCaseSource("TestPerimetrDatas")]
        public double TestForRectangleGetPerimetr(double x, double b)
        {
           Rectangle rectangle = new Rectangle(x,b);
            return rectangle.GetPerimeter();
        }

       public static IEnumerable<TestCaseData> TestAreaDatas
       {
           get
           {
               yield return new TestCaseData(2,5).Returns(10);
               yield return new TestCaseData(3,6).Returns(18);

           }
       }

       [Test, TestCaseSource("TestAreaDatas")]
       public double TestForRectangleGetArea(double x, double b )
       {
           Rectangle rectangle = new Rectangle(x,b);
           return rectangle.GetArea();
       }

#endregion


#region Triangle
       public static IEnumerable<TestCaseData> TestPerimetrDatasTriangle
       {
           get
           {
               yield return new TestCaseData(2, 4, 5).Returns(11);
           }
       }

       [Test, TestCaseSource("TestPerimetrDatasTriangle")]
       public double TestForTriangleGetPerimetr(double x, double b, double c)
       {
           Triangle triangle = new Triangle(x, b,c);
           return triangle.GetPerimeter();
       }


       public static IEnumerable<TestCaseData> TestAreaDatasTriangle
       {
           get
           {
               yield return new TestCaseData(2, 4, 5).Returns(3.799671038392666);
               
           }
       }

       [Test, TestCaseSource("TestAreaDatasTriangle")]
       public double TestForTriangleleGetArea(double x, double b, double c)
       {
           Triangle triangle = new Triangle(x, b, c);
           return triangle.GetArea();
       }

#endregion


       #region Circle
       public static IEnumerable<TestCaseData> TestPerimetrDatasCircle
       {
           get
           {
               yield return new TestCaseData(3).Returns(18.85);
           }
       }

       [Test, TestCaseSource("TestPerimetrDatasCircle")]
       public double TestForCirclesGePerimetr(double x)
       {
           Circles circles = new Circles(x);
           return Math.Round(circles.GetPerimeter(),3);
       }


       public static IEnumerable<TestCaseData> TestAreaDatasCircle
       {
           get
           {
               yield return new TestCaseData(3).Returns(28.274);

           }
       }

       [Test, TestCaseSource("TestAreaDatasCircle")]
       public double TestForCirlesleGetArea(double x)
       {
           Circles circles = new Circles(x);
           return Math.Round(circles.GetArea(),3);
       }

       #endregion


       #region Square
       public static IEnumerable<TestCaseData> TestPerimetrDatasSquare
       {
           get
           {
               yield return new TestCaseData(4).Returns(16);
           }
       }

       [Test, TestCaseSource("TestPerimetrDatasSquare")]
       public double TestForSquareGetPerimetr(double x)
       {
           Square  square = new Square(x);
           return square.GetPerimeter();
       }


       public static IEnumerable<TestCaseData> TestAreaDatasSquare
       {
           get
           {
               yield return new TestCaseData(4).Returns(16);

           }
       }

       [Test, TestCaseSource("TestAreaDatasSquare")]
       public double TestForSquareleGetArea(double x)
       {
           Square square = new Square(x);
           return square.GetArea();
       }

       #endregion
    }
}
