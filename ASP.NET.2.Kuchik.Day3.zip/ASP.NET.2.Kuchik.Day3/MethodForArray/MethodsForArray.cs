﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace MethodForArray
{

    
    public class Methods
    {
        #region Delegate 
        public delegate int[,] DeIncrease(int[,] Ar, int str);
#endregion

        #region PublicMethod
        /// <summary>
        ///  this method finds sum of strings
        /// </summary>
        /// <param name="str"> quality strings</param>
        /// <param name="qualitiElemStr">array</param>
        /// <param name="jaggedArray"> jaggedarray</param>
        /// <param name="deIncrease"> delegate</param>
        /// <returns>result sort</returns>
        public static  int [][] Almount(int str,ref int [] qualitiElemStr, int[][] jaggedArray, DeIncrease deIncrease)
        {
            
             int [,] Almount= new int[str,2];
             for (int i = 0; i < str; i++)
            {
                Almount[i, 1] = i;
                    for (int j = 0; j < qualitiElemStr[i]; j++)
                    {
                        Almount[i, 0] += jaggedArray[i][j];
                    }
                
            }
             return Swap(str, ref qualitiElemStr, jaggedArray, ref Almount, deIncrease);
        }

        /// <summary>
        ///  this method finds maximum value of strings
        /// </summary>
        /// <param name="str"> quality strings</param>
        /// <param name="qualitiElemStr">array</param>
        /// <param name="jaggedArray"> jaggedarray</param>
        /// <param name="deIncrease"> delegate</param>
        /// <returns>result sort</returns>
        public static int[][] Max(int str, ref int[] qualitiElemStr, int[][] jaggedArray, DeIncrease deIncrease)
        {
            int[,] Almount = new int[str, 2];
            for (int i = 0; i < str; i++)
            {
                Almount[i, 1] = i;
               
                    Almount[i, 0] = jaggedArray[i][0];
                    for (int j = 0; j < qualitiElemStr[i]; j++)
                    {
                            if (jaggedArray[i][j] > Almount[i, 0])
                            {
                                Almount[i, 0] = jaggedArray[i][j];
                            }
                   }
            }
            return Swap(str, ref qualitiElemStr, jaggedArray, ref Almount, deIncrease);
        }

        /// <summary>
        ///  this method finds minimum value of strings
        /// </summary>
        /// <param name="str"> quality strings</param>
        /// <param name="qualitiElemStr">array</param>
        /// <param name="jaggedArray"> jaggedarray</param>
        /// <param name="deIncrease"> delegate</param>
        /// <returns>result sort</returns>
        public static int[][] Min(int str, ref int[] qualitiElemStr, int[][] jaggedArray, DeIncrease deIncrease)
        {
            int[,] Almount = new int[str, 2];
            for (int i = 0; i < str; i++)
            {
                Almount[i, 1] = i;
                    Almount[i, 0] = jaggedArray[i][0];
                    for (int j = 0; j < qualitiElemStr[i]; j++)
                    {
                        
                            if (jaggedArray[i][j] < Almount[i, 0])
                            {
                                Almount[i, 0] = jaggedArray[i][j];
                            }
                    }
                }
            return Swap(str, ref qualitiElemStr, jaggedArray, ref Almount, deIncrease);
        }

        /// <summary>
        ///  this method sort array strings
        /// </summary>
        /// <param name="str"> quality strings</param>
        /// <param name="Ar"> array</param>
        /// <returns>result sort on increase </returns>
        public static int[,] SortIncrease(int[,] Ar, int str)
        {
            int i, j;
            int temp;
            int tempid;
            for (i = 0; i < str; i++)
                for (j = str - 1; j > i; j--)
                   
                        if (Ar[(j - 1), 0] > Ar[j, 0])
                        {
                            temp = Ar[j - 1, 0];
                            tempid = Ar[j - 1, 1];
                            Ar[j - 1, 0] = Ar[j, 0];
                            Ar[j - 1, 1] = Ar[j, 1];
                            Ar[j, 0] = temp;
                            Ar[j, 1] = tempid;
                        }
            return Ar;
        }

        /// <summary>
        ///  this method sort array strings
        /// </summary>
        /// <param name="str"> quality strings</param>
        /// <param name="Ar"> array</param>
        /// <returns>result sort on decrease</returns>
        public static int[,] SortDecrease(int[,] Ar, int str)
        {
            int i, j;
            int temp;
            int tempid;
            for (i = 0; i < str; i++)
                for (j = str - 1; j > i; j--)
                    if (Ar[(j - 1), 0] < Ar[j, 0])
                    {
                        temp = Ar[j - 1, 0];
                        tempid = Ar[j - 1, 1];
                        Ar[j - 1, 0] = Ar[j, 0];
                        Ar[j - 1, 1] = Ar[j, 1];
                        Ar[j, 0] = temp;
                        Ar[j, 1] = tempid;
                    }
            return Ar;
        }
#endregion
        #region PrivateMethods

        /// <summary>
        ///  this method reverses the array elements
        /// </summary>
        /// <param name="str"> quality strings</param>
        /// <param name="qualitiElemStr">array</param>
        /// <param name="jaggedArray"> jaggedarray</param>
        /// <param name="deIncrease"> delegate</param>
        /// <returns>ordered array</returns>
        private static int[][] Swap(int str, ref int[] qualitiElemStr, int[][] jaggedArray, ref int[,] Almount, DeIncrease deIncrease)
        {
            Almount = deIncrease.Invoke(Almount, str);
            int[][] jaggedArraynew = new int[str][];
            int[] qualitiElemStrnew = new int[str];

            for (int i = 0; i < str; i++)
            {
                jaggedArraynew[i] = jaggedArray[Almount[i, 1]];
                qualitiElemStrnew[i] = qualitiElemStr[Almount[i, 1]];
            }
            qualitiElemStr = qualitiElemStrnew;
            return jaggedArraynew;
        }

#endregion

        
    }
}
