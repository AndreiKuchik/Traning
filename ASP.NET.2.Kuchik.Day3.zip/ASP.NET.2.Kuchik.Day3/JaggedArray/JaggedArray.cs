﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;
using MethodForArray;
using Microsoft.SqlServer.Server;

namespace JaggedArray
{

   
    class JaggedArray
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter quantity strings  of array");
            int str = new Int32();
            bool flag = true;
            bool deInCrease = new bool();
         
            while (flag)
            {
                try
                {
                    str = Int32.Parse(Console.ReadLine());
                    if (str < 1)
                    {
                        throw new FormatException();
                    }
                    flag = false;
                }
                catch (FormatException exception)
                {
                    Console.WriteLine("Error! Please repeat entry");
                }
            }

            int [] qualitiElemStr = new int[str];
            int [] qualitiElemStr1 = new int[str];
            int [] qualitiElemStr2 = new int[str];
            qualitiElemStr = WriteArray(str, qualitiElemStr);
            qualitiElemStr1 = qualitiElemStr;
            qualitiElemStr2 = qualitiElemStr;

            int[][] jaggedArray = new int[str][];
            for (int i = 0; i < str; i++)
            {
                jaggedArray[i] = new int[qualitiElemStr[i]];

            }

            jaggedArray = WriteJaggedArray(str, qualitiElemStr, jaggedArray);
            
            Console.WriteLine("Array");
            ToDisplayArray(str, qualitiElemStr, jaggedArray);
            
            int[][] jaggedArraynew = new int[str][];
            
            Console.WriteLine("Do you want Sort array by the amount, by decrease(1) or increase(2) ?");
            flag = true;
            int choise;
            
            while (flag)
            {
                choise = Int32.Parse(Console.ReadLine());
                if (choise == 1)
                {
                    jaggedArraynew = Methods.Almount(str,ref qualitiElemStr,jaggedArray,Methods.SortDecrease);
                    flag = false;
                }
                else if (choise == 2)
                {
                    jaggedArraynew = Methods.Almount(str, ref qualitiElemStr, jaggedArray, Methods.SortIncrease);
                    flag = false;
                }
                else
                    Console.WriteLine("Error,  please repeat entry");

            }
            
            
            Console.WriteLine("Array sorted by the amount");
            ToDisplayArray(str, qualitiElemStr, jaggedArraynew);


            Console.WriteLine("Do you want Sort array by the maximum value, by decrease(1) or increase(2) ?");
            flag = true;
            
            while (flag)
            {
                choise = Int32.Parse(Console.ReadLine());
                if (choise == 1)
                {
                    jaggedArraynew = Methods.Max(str,ref qualitiElemStr,jaggedArray,Methods.SortDecrease);
                    flag = false;
                }
                else if (choise == 2)
                {
                    jaggedArraynew = Methods.Max(str, ref qualitiElemStr, jaggedArray, Methods.SortIncrease);
                    flag = false;
                }
                else
                    Console.WriteLine("Error,  please repeat entry");

            }
            
            Console.WriteLine("Array sorted by the maximum value");
            ToDisplayArray(str, qualitiElemStr1, jaggedArraynew);


            Console.WriteLine("Do you want Sort array by the minimum value, by decrease(1) or increase(2) ?");
             flag = true;
            
            while (flag)
            {
                choise = Int32.Parse(Console.ReadLine());
                if (choise == 1)
                {
                    jaggedArraynew = Methods.Min(str,ref qualitiElemStr,jaggedArray,Methods.SortDecrease);
                    flag = false;
                }
                else if (choise == 2)
                {
                    jaggedArraynew = Methods.Min(str, ref qualitiElemStr, jaggedArray, Methods.SortIncrease);
                    flag = false;
                }
                else
                    Console.WriteLine("Error,  please repeat entry");

            }
            
            Console.WriteLine("Array sorted by the minimum value");
            ToDisplayArray(str, qualitiElemStr2, jaggedArraynew);

            Console.ReadKey();
        }




        private static void ToDisplayArray(int str, int [] qualitiElemStr, int [][] jaggedArray)
        {
            for (int i = 0; i < str; i++)
            {
                for (int j = 0; j < qualitiElemStr[i]; j++)
                {
                    Console.Write(" " + jaggedArray[i][j] + " ");
                }
                Console.WriteLine();

            }
            Console.WriteLine();
        }

        private static int[][] WriteJaggedArray(int str, int[] qualitiElemStr, int[][] jaggedArray)
        {
            bool flag;
            for (int i = 0; i < str; i++)
            {
                flag = true;
                Console.WriteLine("Enter elements for string {0}", i + 1);
                for (int j = 0; j < qualitiElemStr[i]; j++)
                {
                    flag = true;
                    while (flag)
                    {
                        try
                        {

                            jaggedArray[i][j] = Int32.Parse(Console.ReadLine());
                            flag = false;
                        }
                        catch (FormatException exception)
                        {
                            Console.WriteLine("Error! Please repeat entry");
                        }
                    }
                }
            }
            return jaggedArray;
        }

        private static int[] WriteArray(int str,int[] qualitiElemStr)
        {
            bool flag;
            for (int i = 0; i < str; i++)
            {
                Console.WriteLine("Enter quantity columns in string {0}", i + 1);
                flag = false;
                while (!flag)
                {
                    try
                    {
                        qualitiElemStr[i] = Int32.Parse(Console.ReadLine());
                        if (qualitiElemStr[i] < 1)
                        {
                            throw new FormatException();
                        }
                        flag = true;
                    }
                    catch (FormatException exception)
                    {
                        Console.WriteLine("Error! Please repeat entry");
                    }
                }
            }
            return qualitiElemStr;
        }

      
          
    }
}
