﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;


namespace MethodsMyFormat
{
    public class MethodsFOrFormat: IFormatProvider, ICustomFormatter
    {
       
        #region Field
        IFormatProvider _num;
        #endregion


        #region PublicMethods

        /// <summary>
        /// Constructor
        /// </summary>
        public MethodsFOrFormat() : this(CultureInfo.CurrentCulture) { }
        
        /// <summary>
        /// Constructor with one parametr
        /// </summary>
        /// <param name="num"></param>
        public MethodsFOrFormat(IFormatProvider num)
        {
            _num = num;
        }

        /// <summary>
        /// IFormatProvider GetFormat()
        /// </summary>
        /// <param name="formatType"></param>
        /// <returns></returns>
        public object GetFormat(Type formatType)
        {
            if (formatType == typeof(ICustomFormatter)) return this;
            return null;
        }

        /// <summary>
        /// ICustomFormatter Format()
        /// </summary>
        /// <param name="format"></param>
        /// <param name="arg"></param>
        /// <param name="prov"></param>
        /// <returns></returns>
        public string Format(string format, object arg, IFormatProvider prov)
        {
            // If it's not our format string, defer to the parent provider:
            if (arg == null || format != "F")
                return string.Format(_num, "{0:" + format + "}", arg);

            int k = (int) arg;
            if (k < 0)
            {
                return TranslateM(k);
            }
            return Translate(k);
        }
        #endregion
        #region PrivateMethods
        /// <summary>
        /// Hex
        /// </summary>
        /// <param name="number"></param>
        /// <returns> result </returns>
        private static string Translate(int number)
        {
            char[] symblos = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

            string result = "";

            while (true)
            {
                result = symblos[number % 16] + result;

                number /= 16;

                if (number == 0)
                    break;
            }

            return "0x" + result;
        }

        /// <summary>
        /// this method translates negative numbers  
        /// </summary>
        /// <param name="number"></param>
        /// <returns> result </returns>
        private static string TranslateM(int number)
        {
            bool isNegative = number < 0;

            if (isNegative)
                number *= -1;

            string hex = Translate(number);

            if (isNegative)
                hex = "-" + hex;

            return hex;
        }
        #endregion
    }
}
