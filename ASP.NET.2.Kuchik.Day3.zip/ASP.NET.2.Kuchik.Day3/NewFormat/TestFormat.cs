﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MethodsMyFormat;

namespace NewFormat
{
    class TestFormat
    {
        static void Main(string[] args)
        {
           
            MethodsFOrFormat f =new MethodsFOrFormat();
            Console.WriteLine( f.Format("F", -43, f));
            Console.WriteLine(f.Format("F", 343, f));
            Console.ReadKey();
        }
    }
}
